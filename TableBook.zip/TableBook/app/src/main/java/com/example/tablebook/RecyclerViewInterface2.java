package com.example.tablebook;

public interface RecyclerViewInterface2 {
    void onItemClick2(int position);
}
