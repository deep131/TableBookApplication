package com.example.tablebook;

public interface RecyclerViewInterface {
    void onItemClick(int position);


}

